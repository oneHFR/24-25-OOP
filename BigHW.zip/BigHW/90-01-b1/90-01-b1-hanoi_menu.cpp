///* 2152131 �ƿ� ����� */
//#include <iostream>
//#include <iomanip>
//#include <conio.h>
////#include "90-01-b1-hanoi.h"
//#include "../include/cmd_console_tools.h"
//
//using namespace std; 
//int menu()
//{
//
//	while (1) {
//		option = _getch();
//		if (option >= '0' && option <= '9') {
//			cout << (int(option - 48)) << endl;
//			cout << endl<<endl;
//			return int(option - 48);
//		}
//		else
//			continue;
//		}
//}
