/* 2152131 �ƿ� ����� */
#include <iostream>
#include <iomanip>
#include <conio.h>
#include "90-01-b2-magic_ball.h"
#include "../include/cmd_console_tools.h"
#include <Windows.h>

using namespace std;





