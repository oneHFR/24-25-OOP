/* 2152131 �ƿ� ����� */
#pragma once
#include <iostream>
#include <iomanip>
#include <conio.h>
#include "../include/cmd_console_tools.h"

/*---------------------------------------------------------------------------------------------------- */
/*ҳ���ʼ��*/
void reset_cmd();
/*�˵���ת*/
int menu(const char* choice);
